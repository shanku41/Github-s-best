/**
*Program: CreditCard
 *This: CreditCard.java
 *Author: Shanku Nair
 *Date: 24-Jul-2019
 *Purpose: To test whether the inputted credit card number is valid 
  */
package creditcard;

import java.util.Scanner;

/**
 *
 * @author shank
 */
public class CreditCard {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean isExit = false;
        while (!isExit) { // creates menu for user
            System.out.println("1. Check for valid credit card number. ");
            System.out.println("2. Exit application ");
            int choice = input.nextInt();
            if (choice == 1) {
                System.out.print("Enter a credit card number as a long integer: ");
                long number = input.nextLong();

                System.out.println(
                        number + " is " + (isValid(number) ? "valid" : "invalid"));
           }
            if (choice == 2) {
                isExit = true;
            }
        }
    }

    public static boolean isValid(long number) { // returns true if card number is valid
        boolean valid
                = (getSize(number) >= 13 && getSize(number) <= 16)
                && (prefixMatched(number, 4) || prefixMatched(number, 5)
                || prefixMatched(number, 37) || prefixMatched(number, 6))
                && ((sumOfDoubleEvenPlace(number) + sumOfOddPlace(number)) % 10 == 0);
        return valid;
    }

    public static int sumOfDoubleEvenPlace(long number) {
        int sum = 0;
        String num = number + "";
        for (int i = getSize(number) - 2; i >= 0; i -= 2) {
            sum += getDigit(Integer.parseInt(num.charAt(i) + "") * 2);
        }
        return sum;
    }

    public static int getDigit(int number) { // returns sum of the two digits
        if (number < 9) {
            return number;
        } else {
            return number / 10 + number % 10;
        }
    }

    public static int sumOfOddPlace(long number) { // returns sum of odd-place digits
        int sum = 0;
        String num = number + "";
        for (int i = getSize(number) - 1; i >= 0; i -= 2) {
            sum += Integer.parseInt(num.charAt(i) + "");
        }
        return sum;
    }

    public static boolean prefixMatched(long number, int d) { // returns true if number d is prefix for number
        return getPrefix(number, getSize(d)) == d;
    }

    public static int getSize(long d) { // returns the amount of digits in d
        String num = d + "";
        return num.length();
    }

    public static long getPrefix(long number, int k) { // returns first k number of sigits of the number
        if (getSize(number) > k) {
            String num = number + "";
            return Long.parseLong(num.substring(0, k));
        }
        return number;
    }
}
