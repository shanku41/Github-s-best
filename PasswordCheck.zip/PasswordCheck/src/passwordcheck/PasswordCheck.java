/**
*Program: PasswordCheck
 *This: PasswordCheck.java
 *Author: Shanku Nair
 *Date: 24-Jul-2019
 *Purpose: To test whether the inputted password meets all the criteria of being a password.   
  */
package passwordcheck;

import java.util.Scanner;

/**
 *
 * @author shank
 */
public class PasswordCheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String password;
        boolean isExit = false;
        while (!isExit) {
            System.out.println("1. Check for valid password. ");
            System.out.println("2. Exit application ");
            int choice = input.nextInt();
            if (choice == 1) {
                System.out.print(" Enter a password:");
                password = input.next();
                System.out.println(
                        (isValidPassword(password) ? "Valid " : "Invalid ") + "Password");
            }
            if (choice == 2) {
                isExit = true;
            }
        }

    }

    public static boolean isValidPassword(String password) {
        final int LENGTH_OF_VALID_PASSWORD = 8;
        final int MINIMUM_NUMBER_OF_DIGITS = 1;
        final int MINIMUM_NUMBER_OF_LETTERS = 1;
        final int MINIMUM_NUMBER_OF_SPECIAL = 1;

        boolean validPassword
                = isLengthValid(password, LENGTH_OF_VALID_PASSWORD)
                && hasSpecialCharacter(password, MINIMUM_NUMBER_OF_SPECIAL)
                && hasDigit(password, MINIMUM_NUMBER_OF_DIGITS) && hasLetter(password, MINIMUM_NUMBER_OF_LETTERS);

        return validPassword;
    }

    public static boolean isLengthValid(String password, int validLength) { // checks for password being at least 8 characters
        return (password.length() >= validLength);
    }

    public static boolean hasDigit(String password, int n) { // checks for password having at least one number
        int numberOfDigits = 0;
        for (int i = 0; i < password.length(); i++) {
            if (Character.isDigit(password.charAt(i))) {
                numberOfDigits++;
            }
            if (numberOfDigits >= n) {
                return true;
            }
        }
        return false;

    }

    public static boolean hasSpecialCharacter(String password, int n) { // checks for password having at least one special character
        int numberOfLetters = 0;
        for (int i = 0; i < password.length(); i++) {
            switch (password.charAt(i)) {
                case '#':
                    numberOfLetters++;
                case '!':
                    numberOfLetters++;
                case '@':
                    numberOfLetters++;
                case '%':
                    numberOfLetters++;
                case '*':
                    numberOfLetters++;
            }
            if (numberOfLetters >= n) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasLetter(String password, int n) { // checks for password having at least one alphabet character
        int numberOfLetters = 0;
        for (int i = 0; i < password.length(); i++) {
            if (Character.isLetter(password.charAt(i))) {
                numberOfLetters++;
            }
            if (numberOfLetters >= n) {
                return true;
            }
        }
        return false;
    }
}
