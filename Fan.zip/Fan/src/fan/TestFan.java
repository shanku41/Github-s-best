/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fan;

import java.util.Scanner;

/**
 *
 * @author shank
 */
public class TestFan {

    public static void main(String[] args) {

        int number;
        Scanner in = new Scanner(System.in); // create scanner // gives user choice as to which fan they would like to choose
        System.out.println(" Enter 1 to display fan 1"); 
        System.out.println(" Enter 2 to display fan 2 ");
        number = in.nextInt();

        if (number == 1) {
            Fan fan1 = new Fan();
            fan1.setSpeed(Fan.FAST);
            fan1.setRadius(10);
            fan1.setColor("yellow");
            fan1.setOn(true);
            System.out.println(fan1.toString());

        }
        if (number == 2) {
            Fan fan2 = new Fan();
            fan2.setSpeed(Fan.MEDIUM);
            fan2.setRadius(5);
            fan2.setColor("blue");
            System.out.println(fan2.toString());
        }
    }
}
