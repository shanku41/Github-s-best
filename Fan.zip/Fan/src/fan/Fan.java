/**
*Program: Fan
 *This: Fan.java
 *Author: Shanku Nair
 *Date: 21-Jul-2019
 *Purpose: Design a class named fan to represent a fan 
  */
package fan;

/**
 *
 * @author shank
 */
public class Fan {

    public static int SLOW = 1;  // creates constants as speeds
    public static int MEDIUM = 2;
    public static int FAST = 3;

    private int speed = SLOW;
    private boolean on = false;
    private double radius = 5;
    private String color = "blue";

    public Fan() {
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String toString() { // method that returns string description for fan
        String result = " speed = " + speed + " color = " + color + " radius = " + radius;
        if (isOn()) {
            result += " fan is on"; 
        } else {
            result = " color = " + color + " radius = " + radius + " fan is off";
        }
        return result;
    }

}
